import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {openDatabase} from '../server/database.js';
import {sendChatMessage} from '../server/chat.js';
const dir=mkdtempSync(join(tmpdir(),'mylittlia-v0298-'));
try {
 const db=openDatabase(join(dir,'db.sqlite'));
 let id;
 for (const [question,expected] of [
 ['Quem é você?',/inteligência artificial experimental/i],
 ['Quando vc foi criada e por quem?',/não tenho uma data de criação nem autoria confirmadas/i],
 ['E o que vc faz?',/consultar conhecimentos armazenados no SQLite/i],
 ['Para que você serve?',/inferências/i],
 ['Qual sua versão?',/v0\.29\.8/]
 ]) {
  const response=sendChatMessage(db,{text:question,conversationId:id});
  id=response.conversationId;
  assert.match(response.reply,expected,question);
 }
 db.close();
 console.log('PASS self-awareness v0.29.8');
} finally {rmSync(dir,{recursive:true,force:true});}
