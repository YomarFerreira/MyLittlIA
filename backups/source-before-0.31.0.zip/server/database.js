import { registerNeuralExamples } from './neural-examples.js';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { randomUUID } from 'node:crypto';

export const normalize = text => String(text).toLocaleLowerCase('pt-BR')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

export function openDatabase(path, { seed = true } = {}) {
    mkdirSync(dirname(path), { recursive: true });
    // A atualização nunca remove nem recria um banco já existente.
    const isNewDatabase = !existsSync(path);
    const db = new DatabaseSync(path);
    db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
    // Schema is versioned. Future changes belong in separate migrations.
    const migrated = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'").get();
    if (!migrated || !db.prepare('SELECT version FROM schema_migrations WHERE version=1').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT OR IGNORE INTO schema_migrations(version) VALUES (1)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // Os exemplos iniciais são adicionados apenas na criação do banco.
    // Assim, uma exclusão feita pelo usuário não reaparece após reiniciar.
    if (seed && isNewDatabase) {
        const defaults = JSON.parse(readFileSync(new URL('../data/seed.json', import.meta.url), 'utf8'));
        db.exec('BEGIN');
        try {
            const knowledgeInsert = db.prepare(`INSERT OR IGNORE INTO knowledge
                (id,question,normalized_question,answer,intent,origin) VALUES (?,?,?,?,?,?)`);
            for (const item of defaults.knowledge) {
                knowledgeInsert.run(item.id || randomUUID(), item.question, normalize(item.question), item.answer, item.intent, 'seed');
            }
            const exampleInsert = db.prepare(`INSERT OR IGNORE INTO training_examples
                (text,normalized_text,label,source) VALUES (?,?,?,?)`);
            for (const item of defaults.examples) exampleInsert.run(item.text, normalize(item.text), item.label, 'seed');
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // Migração incremental v2: nunca recria nem substitui o arquivo SQLite existente.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=2').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v2.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (2)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=3').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v3.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (3)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=4').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v4.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (4)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=5').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v5.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (5)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=6').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v6.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (6)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=7').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v7.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (7)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=8').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v8.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (8)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=9').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v9.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (9)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v10 — catálogo linguístico e exemplos de treinamento migrados para SQLite.
    // INSERT OR IGNORE ocorre apenas uma vez e nunca sobrescreve edições do usuário.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=10').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v10.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (10)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v11 — preferências persistidas no mesmo SQLite. Não modifica registros existentes.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=11').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v11.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (11)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v12 — modelos de resposta no SQLite; bootstrap único, preservando alterações futuras.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=12').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v12.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (12)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v13 — templates de propriedades sem sobrescrever edições do usuário.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=13').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v13.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (13)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v14 — apresentação de classificações contextuais orientada pelo SQLite.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=14').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v14.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (14)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v15 — catálogo de expressão semântica por predicado; não altera fatos nem pesos.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=15').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v15.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (15)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v16 — formas linguísticas para vocalizações, sem alterar conhecimentos pessoais.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=16').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v16.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (16)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v17 — template de descrição de vocalizações, sem sobrescrever personalizações.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=17').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v17.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (17)').run();
            db.exec('COMMIT');
        } catch (error) {db.exec('ROLLBACK'); throw error;}
    }
    // v18 — propostas revisáveis e procedência dos fatos, sem alterar registros pessoais.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=18').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v18.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (18)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v19 — sinônimos e equivalências linguísticas no catálogo SQLite existente.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=19').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v19.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (19)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v20 — controle de contexto conversacional sem alterar conhecimentos existentes.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=20').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v20.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (20)').run();
            db.exec('COMMIT');
        } catch (error) {db.exec('ROLLBACK'); throw error;}
    }
    // v21 — respostas nacionais para caminhos territoriais derivados de fatos existentes.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=21').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v21.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (21)').run();
            db.exec('COMMIT');
        } catch (error) {db.exec('ROLLBACK'); throw error;}
    }
    // v22 — fatos tipados por entidade (tempos, fontes e competições), sem alterar o grafo anterior.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=22').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v22.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (22)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v23 — métricas e equivalências configuradas no SQLite (rankings comparáveis).
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=23').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v23.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (23)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // v24 — apresentação natural de vocalizações; sem alteração de fatos.
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=24').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v24.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (24)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=25').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v25.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (25)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    if (!db.prepare('SELECT version FROM schema_migrations WHERE version=26').get()) {
        db.exec('BEGIN');
        try {
            db.exec(readFileSync(new URL('./migration-v26.sql', import.meta.url), 'utf8'));
            db.prepare('INSERT INTO schema_migrations(version) VALUES (26)').run();
            db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    // Reaproveita o historico v0.13.2 sem exigir novo treinamento.
    // Reprocessamento idempotente: pares e vinculos possuem UNIQUE/PRIMARY KEY.
    db.exec('BEGIN IMMEDIATE');
    try {
        const previous = db.prepare('SELECT id,training_text FROM neural_training_runs').all();
        for (const run of previous) registerNeuralExamples(db,run.id,run.training_text);
        db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return db;
}

export const listKnowledge = db => db.prepare('SELECT id,question,answer,intent,origin FROM knowledge ORDER BY created_at,id').all();
export const listExamples = db => db.prepare('SELECT id,text,label,source FROM training_examples ORDER BY id').all();

function validateKnowledge(item) {
    const question = String(item?.question ?? '').trim();
    const answer = String(item?.answer ?? '').trim();
    const intent = String(item?.intent || 'outro').trim();
    if (question.length < 5 || question.length > 500 || !answer || answer.length > 1200 || intent.length > 80) {
        throw Object.assign(new Error('Pergunta (5–500 caracteres), resposta (1–1200) ou intenção inválida.'), { status: 400 });
    }
    return { question, answer, intent, normalized: normalize(question) };
}
export function createKnowledge(db, payload, origin = 'user') {
    const item = validateKnowledge(payload);
    const id = randomUUID();
    try {
        db.prepare(`INSERT INTO knowledge (id,question,normalized_question,answer,intent,origin)
            VALUES (?,?,?,?,?,?)`).run(id, item.question, item.normalized, item.answer, item.intent, origin);
    } catch (error) {
        if (String(error).includes('UNIQUE')) throw Object.assign(new Error('Pergunta já cadastrada.'), { status: 409 });
        throw error;
    }
    return db.prepare('SELECT id,question,answer,intent,origin FROM knowledge WHERE id=?').get(id);
}
export function editKnowledge(db, id, payload) {
    const item = validateKnowledge(payload);
    try {
        const result = db.prepare(`UPDATE knowledge SET question=?,normalized_question=?,answer=?,intent=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .run(item.question, item.normalized, item.answer, item.intent, id);
        if (!result.changes) throw Object.assign(new Error('Conhecimento não encontrado.'), { status: 404 });
    } catch (error) {
        if (String(error).includes('UNIQUE')) throw Object.assign(new Error('Pergunta já cadastrada.'), { status: 409 });
        throw error;
    }
    return db.prepare('SELECT id,question,answer,intent,origin FROM knowledge WHERE id=?').get(id);
}
export function removeKnowledge(db, id) {
    return db.prepare('DELETE FROM knowledge WHERE id=?').run(id).changes > 0;
}
export function mergeKnowledge(db, items, origin = 'browser-import') {
    if (!Array.isArray(items) || items.length > 5000) throw Object.assign(new Error('Lista inválida (máximo 5000).'), { status: 400 });
    let added = 0, skipped = 0;
    db.exec('BEGIN');
    try {
        const insert = db.prepare(`INSERT OR IGNORE INTO knowledge
            (id,question,normalized_question,answer,intent,origin) VALUES (?,?,?,?,?,?)`);
        for (const raw of items) {
            const item = validateKnowledge(raw);
            const result = insert.run(randomUUID(), item.question, item.normalized, item.answer, item.intent, origin);
            if (result.changes) added++; else skipped++;
        }
        db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return { added, skipped };
}
// Importação explícita: atualiza registros existentes por pergunta normalizada,
// preserva IDs e todas as perguntas omitidas do JSON. Transação integral.
export function importKnowledgeUpdates(db, items) {
    if (!Array.isArray(items) || items.length > 5000) {
        throw Object.assign(new Error('Lista inválida (máximo 5000).'), { status: 400 });
    }
    const validated = items.map(validateKnowledge);
    const seen = new Set();
    for (const item of validated) {
        if (seen.has(item.normalized)) {
            throw Object.assign(new Error('Pergunta duplicada no JSON: ' + item.question), { status: 400 });
        }
        seen.add(item.normalized);
    }
    let added = 0, updated = 0, unchanged = 0;
    db.exec('BEGIN');
    try {
        const find = db.prepare('SELECT id,question,answer,intent FROM knowledge WHERE normalized_question=?');
        const update = db.prepare(`UPDATE knowledge SET question=?,answer=?,intent=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`);
        const insert = db.prepare(`INSERT INTO knowledge(id,question,normalized_question,answer,intent,origin)
            VALUES (?,?,?,?,?,'json-import')`);
        for (const item of validated) {
            const old = find.get(item.normalized);
            if (!old) {
                insert.run(randomUUID(), item.question, item.normalized, item.answer, item.intent);
                added++;
            } else if (old.question !== item.question || old.answer !== item.answer || old.intent !== item.intent) {
                update.run(item.question,item.answer,item.intent,old.id);
                updated++;
            } else unchanged++;
        }
        db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return { added, updated, unchanged };
}

export function addTrainingExample(db, raw) {
    const text = String(raw?.text || '').trim();
    const label = String(raw?.label || '').trim();
    const labels = new Set(['bebida','comida','capital','saudacao','nome','outro']);
    if (!text || text.length > 300 || !labels.has(label)) throw Object.assign(new Error('Exemplo ou intenção inválidos.'), { status: 400 });
    const result = db.prepare(`INSERT OR IGNORE INTO training_examples (text,normalized_text,label,source)
        VALUES (?,?,?,'user')`).run(text, normalize(text), label);
    if (!result.changes) throw Object.assign(new Error('Exemplo já cadastrado.'), { status: 409 });
    return { id: Number(result.lastInsertRowid), text, label };
}
export function saveTraining(db, run) {
    const id = randomUUID();
    db.exec('BEGIN');
    try {
        db.prepare('INSERT INTO training_runs (id,epochs,learning_rate,example_count) VALUES (?,?,?,?)')
            .run(id, run.epochs, run.rate, run.examples);
        const insert = db.prepare(`INSERT INTO training_metrics
            (run_id,epoch,loss,val_loss,accuracy,val_accuracy) VALUES (?,?,?,?,?,?)`);
        for (const point of run.history) insert.run(id, point.epoch, point.loss, point.valLoss, point.accuracy, point.valAccuracy);
        db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return id;
}
export function saveInference(db, trace) {
    const id = randomUUID();
    const answer = trace.steps.at(-1)?.output?.answer ?? '';
    const source = trace.steps.at(-1)?.output?.knowledgeSource ?? 'unknown';
    db.exec('BEGIN');
    try {
        db.prepare(`INSERT INTO inference_runs
            (id,prompt,answer,source,input_tokens,output_tokens) VALUES (?,?,?,?,?,?)`)
            .run(id, trace.prompt, answer, source, trace.metrics.inputTokens, trace.metrics.outputTokens);
        const insert = db.prepare(`INSERT INTO inference_steps
            (inference_id,step_number,name,mode,step_json) VALUES (?,?,?,?,?)`);
        for (const step of trace.steps) insert.run(id, step.step, step.name, step.mode, JSON.stringify(step));
        db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return id;
}
