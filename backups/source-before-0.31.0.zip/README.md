# MylittlIA Lab — v0.30.14

## v0.30.14 — Comparações genéricas e novo Lote 020 (07/11/2026)

O motor agora identifica quantidade solicitada, classe, abrangência e critério de comparação sem despejar listas enormes. Por exemplo, **“Quais os 3 maiores clubes do Brasil?”** pede critério; **“Por torcida”** apresenta percentuais comparáveis. As orientações de instalação, fontes e limitações do Lote 020 estão na seção **Lotes de conhecimento (019 e 020)** deste README. A migração v23 é automática na abertura do SQLite existente, sem remover relações, fatos, pesos ou histórico.

**Não reinstale a pasta `data/`.** Faça backup antes de atualizar. Importe apenas o Lote 020 (`--dry-run`, depois `--apply`) se já tinha importado 017–019. Não precisa refazer lotes anteriores.

## v0.30.13 — Lote 019: clubes, estádios, títulos, torcidas e participações (07/11/2026)

**Importante:** nesta versão há um lote adicional, que deve ser executado manualmente após atualizar os arquivos, sem apagar a pasta `data/`. O procedimento `--dry-run`/`--apply`, os testes e as limitações estão na seção **Lotes de conhecimento (019 e 020)** deste README.

A migration v22 adiciona `entity_facts`, `entity_fact_aliases` e `entity_labels`, sem mudar as informações anteriores. O lote é idempotente, inclui proveniência, referência temporal, competições e valores financeiros tipados, sem inventar totais históricos de participação ou patrimônios inexistentes. O leitor integrado consulta essas propriedades na conversa.

## v0.30.12 — Inferência geográfica e propriedades por grupo

Consultas como “Quais os clubes do Brasil?” agora usam o caminho lógico clube → município (quando conhecido) → estado → Brasil, sem criar fatos ou sobrescrever relações no SQLite. Perguntas sobre cores, títulos e faturamento por localidade consultam somente os atributos existentes de cada clube e explicam as lacunas. “Tamanho” exige critério mensurável. Uma resposta nacional é sempre parcial: reflete os clubes cadastrados, não todos os clubes reais. A atualização introduz a migração v21, limitada a templates de resposta.

## v0.30.11 — Conversa no formato pergunta + resposta

A área **Conversa com a MylittlIA** apresenta cada interação como um cartão inteiro. A pergunta aparece em um balão largo, à direita; a resposta aparece abaixo, diretamente sobre o fundo do cartão, sem segundo balão. As setas de classificação ordenam **interações completas** por data, mantendo a pergunta antes da resposta em ambas as opções. A preferência segue persistida no SQLite. Cada mensagem preserva seu horário; milissegundos são exibidos quando disponíveis.

**Atualização da interface:** encerre o Node.js, faça backup da pasta `data/` e extraia este ZIP completo sobre sua instalação atual. Mantenha sua pasta `data/`: ela não faz parte do pacote. Reinicie a aplicação e, se o navegador apresentar o layout antigo, recarregue a página com `Ctrl+F5`. Não é necessário executar imports ou migrações adicionais.

**Validação:** `npm run test:chat-layout`, `npm run test:chat-order` e `npm run test:focus`.

## v0.30.10 — Continuidade de conversa por domínio

**Atualização v0.30.10 — continuidade de conversa por domínio.** A aplicação deixa de reaproveitar um ranking municipal quando a conversa mudou para futebol, animais ou outras entidades. “E do Sport?” após uma pergunta sobre cores mantém apenas a propriedade “cores”; uma pergunta sobre títulos distingue ausência de registros de desconhecimento genérico; “qual o maior deles?” pede critério verificável. O código utiliza dados já aprovados no SQLite e templates conversacionais da migration v20.

- **Instalação:** encerre o Node.js, faça backup da pasta `data/` e substitua os arquivos da aplicação. A migration v20 é aplicada automaticamente na próxima inicialização.
- **Dados:** nenhuma relação, peso, conhecimento pessoal ou checkpoint é alterado pela migration.
- **Teste específico:** `npm run test:focus`.
- **Teste de regressão:** `node tests/lexical-equivalence-v0309.test.mjs` e `node tests/municipal-lookup-v02910.test.mjs`.
- **Limitação:** ainda não há base comprovada de títulos/torcidas para elaborar ranking dos principais clubes. O sistema não deve inventá-lo.

---

## Visão geral do projeto

**Histórico de funcionalidades desde a v0.29.10** — laboratório educacional de IA com conversa, conhecimentos relacionais, inferência ponderada e modelos neurais experimentais.

## v0.29.4 — Ordem do chat configurável e horário em cada mensagem
- Escolha **Recentes primeiro** (padrão) ou **Antigas primeiro** no painel de conversa. A ordem fica gravada no SQLite, tabela `app_preferences` (migration v11), e é restaurada ao abrir o sistema.
- Mensagens e respostas permanecem agrupadas por interação; no modo invertido, a interação mais recente aparece no topo, com pergunta acima da resposta.
- Cada mensagem exibe data e hora locais. O horário vem do `created_at` da mensagem persistida em UTC no SQLite, inclusive após restaurar a conversa.
- Alterar a ordem modifica só a apresentação, nunca a sequência cronológica real ou o contexto processado no backend.
- Não substitua a pasta `data`; faça backup antes de atualizar. Nenhum modelo neural precisa ser retreinado.

## v0.29.3 — Limpeza da mensagem e estatísticas sobre rankings
- O campo Mensagem é limpo ao iniciar o envio e devolve o foco ao usuário. Se o servidor falhar, a mensagem é recuperada. Envios simultâneos são bloqueados.
- Média aritmética, mediana numérica e cidades centrais são calculadas com valores reais das relações numéricas no SQLite.
- Complementos como “E a mediana?”, “E a média?” e “E a do meio?” reutilizam entidade e critério do contexto semântico.
- Para conjuntos pares, a mediana é a média dos dois valores centrais; “a do meio” apresenta as duas cidades centrais.
- Não inventa estatísticas para municípios sem dados, nem declara um ranking parcial como se cobrisse todo o estado.

## v0.29.2 — Correção de nomes descritivos de estados

O interpretador reconhece **"estado de Pernambuco"** como a mesma entidade `pernambuco`, mesmo que nomes descritivos existam em relações antigas. Os municípios e áreas já cadastrados continuam no SQLite e são consultados pelas chaves canônicas. Não há migration nova.

## v0.29.1 — Correção do treinamento e migrations

Na v0.29.0, `npm run train:intent` abria o SQLite diretamente, mas a nova tabela `intent_training_samples` só era criada pela migration v10 na inicialização do servidor. Agora há um comando independente para executar as migrations, e `--apply` também aplica migrations pendentes antes de treinar.

**Antes de executar os comandos abaixo, encerre o servidor Node.js e faça backup da pasta `data`.** No diretório raiz do projeto:

```powershell
npm run db:migrate              # aplica migrations pendentes; preserva conhecimentos
npm run train:intent            # apenas consulta os exemplos; não altera o banco
npm run train:intent -- --apply # treina e salva o modelo de intenção no SQLite
npm start                       # reinicie o servidor na versão atual
```

O treinamento com `--apply` também executa migrations pendentes, mas o comando separado deixa o procedimento verificável. Se você usar outro banco, acrescente `-- --db C:\caminho\mylittlia.db` no comando de migração ou `-- --db ...` no script de treinamento (para combinar `--apply`, utilize `-- --apply --db ...`). Os comandos verificam que o arquivo existe; não criam outro banco silenciosamente. O `ExperimentalWarning` do Node.js 22 é independente desse erro. Se o console ainda exibir a versão v0.28.2, encerre a instância antiga e reinicie o servidor após atualizar.

## v0.29.0 — Catálogo de linguagem e treinamento no SQLite

**Objetivo:** mover DADOS LINGUÍSTICOS do JavaScript para tabelas editáveis, mantendo os algoritmos de interpretação e treinamento no código. A migração aditiva **v10** roda uma única vez no primeiro início da versão e não substitui conhecimentos, pesos, históricos ou checkpoints. **Faça backup da pasta `data` antes de atualizar.**

### Novas tabelas

| Tabela | Conteúdo | Atualização |
|---|---|---|
| `semantic_terms` | sinônimos, correções, aliases de UFs | consultada a cada mensagem |
| `semantic_entities` | chave da entidade, nome com acento e artigo (`de`, `do`, `da`) | consultada ao responder |
| `semantic_social_cues` | expressões para reconhecimento social | consultada a cada mensagem |
| `semantic_social_responses` | textos de cumprimento, agradecimento etc. | consultada a cada mensagem |
| `intent_training_samples` | exemplos rotulados que treinam nosso classificador de intenção | utilizados ao **retreinar explicitamente** |

Os registros iniciais são instalados pela migration SQL, não por um JSON executado em cada conversa. Depois de criada a tabela, você pode editar seu conteúdo pelo SQLiteStudio. Exemplo:

```sql
-- Acrescentar uma equivalência: palavras devem ser guardadas normalizadas.
INSERT OR IGNORE INTO semantic_terms(language,kind,phrase,canonical,origin)
VALUES ('pt-BR','lexical','metropoli','cidade','user');

-- Consultar aliases/termos (sem alterar conhecimentos do grafo).
SELECT kind, phrase, canonical, active FROM semantic_terms ORDER BY kind, phrase;

-- Corrigir exibição do nome próprio, sem modificar a chave utilizada no grafo.
UPDATE semantic_entities SET display_name='Macapá' WHERE entity_id='macapa';

-- Dar um novo exemplo ao classificador do zero.
INSERT OR IGNORE INTO intent_training_samples(label,text,normalized_text,origin)
VALUES ('greeting','Olá minha amiga','ola minha amiga','user');
```

Atenção: **editar exemplos de treinamento não modifica automaticamente os pesos neurais**. Para treinar o classificador usando os exemplos ativos do SQLite, com o servidor desligado e um backup do banco:

```powershell
npm run train:intent              # prévia, sem gravar
npm run train:intent -- --apply   # retreina e atualiza somente o modelo de intenção
```

O script aceita `--db C:\caminho\para\mylittlia.db`. As outras redes experimentais continuam independentes. Modelos já treinados são preservados na atualização; não há retreinamento implícito.

**Escopo e limites:** esta etapa migra as tabelas de sinônimos/aliases, nomes, cumprimentos e exemplos do classificador do núcleo v0.28. Outras regras gramaticais, padrões de ranking, interpretações temporais e templates restantes **ainda existem em JavaScript**. Isso não torna o projeto uma LLM multilíngue: para idiomas adicionais é necessário definir dados, exemplos, treinamento e testes por idioma. O SQLite não substitui uma rede neural nem aprende apenas por guardar frases.

## v0.28.3 — Auditoria e revisão segura
A área **Cadastrar conhecimento** mostra alertas para informações pendentes que parecem ser saudações, perguntas novas ou assuntos pouco relacionados. O botão **Auditar pendências** reanalisa os registros antigos sem os modificar. Registros claramente inválidos não podem ser aprovados; itens que precisam de atenção exigem confirmação explícita. Para rejeitar uma informação, selecione-a e use **Rejeitar selecionados**. Nenhum registro é excluído automaticamente. O botão de acesso está em amarelo.

## v0.28.2 — Continuação de conversa e novos conhecimentos

O resolvedor `server/ellipsis-resolver.js` usa o **último frame relacional** armazenado por conversa no SQLite. Exemplo: `O que o gato bebe?` → `E leite?` reconstrói uma consulta sobre **gato + bebe + leite**. Para `E o cachorro?`, se houver relações de cachorro com o mesmo predicado, trata-se de uma **troca de sujeito**. O resolvedor evita afirmar que algo é falso apenas porque não consta na base.

A rede neural própria continua experimental; este resolvedor não é um Transformer ou uma LLM e não aprende automaticamente novas relações. Frases ambíguas podem ainda exigir esclarecimento.

### Importador seguro de conhecimentos (execução opcional)

O arquivo `imports/knowledge-topics-v0282.json` contém capitais e regiões do Brasil (IBGE), exemplos selecionados de localização de municípios, classificações de animais (museu de Oxford), bebidas e cores (fontes didáticas). **Não é um cadastro completo de todos os municípios nem um ranking de cidades.** Informação sem fonte documental específica é marcada como introdutória, não verificada.

1. Encerre a aplicação e **faça backup da pasta `data` inteira**, inclusive arquivos SQLite auxiliares.
2. Revise o arquivo JSON de relações e suas referências.
3. Execute a simulação, que abre o banco em modo **somente leitura**:

```powershell
node imports/import-conhecimentos-v0282.mjs --dry-run
```

4. Para incorporar as relações (não altera pesos de relações existentes):

```powershell
node imports/import-conhecimentos-v0282.mjs --apply
```

É possível escolher outro banco com `--db C:\caminho\arquivo.db`. Não cria banco novo quando ele não existe. O importador identifica conflitos em propriedades únicas, não os resolve automaticamente, e salva metadados documentais em `imported_knowledge_provenance`. O arquivo JSON é **somente um conjunto de dados de entrada**: a memória da MylittlIA continua no SQLite.

**Gatos e leite:** não importamos a afirmação de que leite de vaca seja recomendado a gatos adultos; muitos gatos são intolerantes à lactose. A relação com água é distinta de permissões/recomendações alimentares.

Teste dirigido: `node tests/ellipsis-v0282.test.mjs` e `node tests/import-topics-v0282.test.mjs`.

## v0.28.1 — Continuidade semântica de critérios e estado
- Aceita esclarecimentos curtos como “Extensão” e “População”, sem exigir “em” ou “por”.
- Mantém a escolha de ordenação e posição ao esclarecer o critério, evitando respostas recuperadas de outro assunto.
- Ao continuar uma consulta, pode trocar a unidade federativa mantendo o critério previamente esclarecido.
- Responde a perguntas sobre os próprios esclarecimentos, sem reclassificá-las como aprendizado.
- Se não há medidas numéricas, explica a ausência para o indicador/estado correto em vez de recuperar uma lista de outra categoria.
- Não altera conhecimentos, avaliações, checkpoints ou o esquema do SQLite.

## v0.28 — Núcleo de Compreensão e Planejamento Semântico

- O módulo `server/semantic-core.js` coordena a interpretação de **saudações + pergunta social**, consultas de capitais, localizações regionais e rankings municipais. O classificador neural próprio fornece um **sinal auxiliar**; não decide sozinho fatos ou respostas.
- A interpretação diferencia `intents`, `entity`, `property`, `operation`, `order`, `position` e `pendingClarification`. Um mesmo texto pode expressar duas intenções, como saudação e pedido de informação.
- Correções conservadoras de digitação em vocabulário limitado, como `capita → capital`, são hipóteses de consulta, nunca alterações da mensagem original ou provas de verdade.
- `server/proper-names.js` separa identificadores normalizados de nomes para exibição, preservando, entre outros, **Amapá**, **Macapá**, **Pernambuco**, **Recife** e **Lagoa Grande**.
- Quando “maior cidade” não define população, extensão ou PIB, a MylittlIA **pede esclarecimento**. Respostas curtas como “Em extensão” e “E a menor?” atualizam o plano; o resultado só é construído a partir de medidas consultadas.
- Migração incremental **v9**: `conversation_semantic_state` guarda o estado por conversa no mesmo SQLite, sem recriar nem apagar dados anteriores. Nenhuma conclusão inferida é registrada automaticamente como fato.
- O validador `server/response-validator.js` verifica, nas operações cobertas, se a entidade, a propriedade e as evidências recuperadas correspondem ao plano antes de aceitar a resposta. Isso não substitui uma verificação externa de fatos.
- A etapa 6 do inspetor exibe o plano e as correções: a aba simples explica a interpretação em linguagem acessível, e a aba técnica mostra intenções, estado anterior/atualizado, evidências e sinal do classificador.
- As regras anteriores ainda atuam como **fallback** quando o núcleo não possui uma operação suficientemente compreendida. O interpretador **não é uma LLM generativa** e não garante compreensão universal de linguagem; sua cobertura é deliberadamente limitada e testável.

**Teste de regressão:** `npm test` inclui `tests/semantic-core-v28.test.mjs`. Também pode ser executado isoladamente: `node tests/semantic-core-v28.test.mjs`.

## Início rápido

Requisitos: Node.js >= 22.13.0 e acesso local ao projeto. No diretório da aplicação:

```powershell
npm start
```

Abra `http://127.0.0.1:8000` no navegador. Para rodar os testes:

```powershell
npm test
```

## Organização das telas

- **Conversar com a MylittlIA:** mensagens, histórico persistente, nove camadas de processamento, inspetor com Explicação simples e Detalhes técnicos. A área da conversa pode ser redimensionada verticalmente.
- **Treinar a MylittlIA:** botão amarelo na tela de conversa. Reúne cadastro/revisão de conhecimentos, relações, exemplos, classificador neural e gerador experimental. Use **Voltar à conversa** para retornar sem reiniciar.
- **Exemplos armazenados e memória:** dentro do laboratório neural generativo na tela de treinamento. Permite consultar exemplos, selecionar e incorporar à memória. Exemplos já incorporados deixam a lista de pendências; conflitos não substituem automaticamente respostas existentes.

## Conhecimentos e aprendizado

- O SQLite armazena conhecimentos, relações e seus pesos, conversas, propostas pendentes, exemplos e dados persistentes de treinamento neural.
- **Conhecimento cadastrado** é algo aprovado e disponível para consulta. **Exemplo de treino** não equivale necessariamente a conhecimento aprovado. **Conhecimento inferido** resulta da composição de relações existentes e não é gravado automaticamente como fato independente.
- Se a MylittlIA não sabe responder, pode pedir ajuda. Uma explicação recebida é registrada como **pendente de revisão**; a aprovação é realizada na área de treinamento. A coleta de informação não equivale a um treinamento automático dos pesos neurais.
- A inferência relacional é ponderada e limitada às regras implementadas; pontuações não devem ser interpretadas como probabilidades comprovadas de verdade.
- O interpretador semântico consulta propriedades e aliases reconhecidos, tais como algumas capitais, bandeiras, municípios de referência, praias, economia, indústrias, empresas, área e população, conforme os dados efetivamente existentes. Não é uma compreensão irrestrita de linguagem natural; rankings municipais não verificados não são inventados.

## Laboratórios neurais

O projeto mantém modelos experimentais por caracteres e palavras. Treinamento, vocabulário e pesos são persistidos no SQLite. A geração de texto experimental é distinta da recuperação de fatos utilizada pela conversa: seus tokens previstos não são necessariamente respostas à pergunta.

## Importação de relações

Importações são **explícitas**, não acontecem automaticamente só pela instalação:

```powershell
npm run import:animals
node imports/import-brasil-geografia.mjs --dry-run
node imports/import-brasil-geografia.mjs --apply
```

Revise os arquivos e faça backup antes de importar. O conjunto animal fica em `imports/animal-relations.tsv`. A importação foi projetada para evitar duplicações e preservar pesos existentes; resultados dependem dos dados presentes no banco.


## Lotes de conhecimento (019 e 020)

Os lotes são **importações opcionais e explícitas**. A atualização da aplicação não insere esses fatos automaticamente. Para preservar seus dados, encerre o servidor, faça backup de `data/`, execute `--dry-run` antes de `--apply` e **não reimporte lotes que já estão presentes**. As instruções e referências de cada lote foram consolidadas abaixo, sem documentos README separados.

### Lote 019 — Futebol brasileiro: clubes, estádios, títulos, torcidas e competições

**Compatibilidade:** MylittlIA Lab v0.30.13 ou superior. Data de referência: 07/11/2026.

#### Conteúdo verificável

- **401 fatos tipados** para **102 identificadores de clubes**, incluindo participações, campeonatos e indicadores.
- **39 cidades-sede**, **38 estádios de referência**, **78 relações territoriais documentadas** (municípios e clubes).
- **188 participações**: Série A (20 em 2025 e 20 em 2026), Série B (20 em 2026), Copa do Brasil 2026 (cerca de 98 associações inequívocas do catálogo existente) e estaduais com participação comprovada pela presença na final.
- **62 contagens de títulos**, **31 títulos identificados por temporada**, **19 sequências de participações consecutivas na Série A**.
- **17 percentuais de torcida AtlasIntel 2025**, **5 indicadores de receitas de 2025 sem vendas de jogadores**, **2 números de patrimônio líquido contábil de 2025**.
- **47 nomes de clubes apresentados corretamente** quando houver correspondência exata; os demais continuam com o identificador atual.

Nenhuma das métricas de 2025 é tratada como se fosse a de 2026.

#### Instalação (não apaga seu SQLite)

1. **Pare o Node.js e faça backup da pasta `data/`.**
2. Extraia o ZIP **completo v0.30.13** na pasta da instalação atual (por exemplo `C:\workspace\mylittlia`). **Não exclua nem substitua sua pasta `data/`.**
3. Execute na raiz do projeto:

```powershell
node imports/import-mylittlia-lote-019-futebol-brasil-2026.mjs --dry-run
node imports/import-mylittlia-lote-019-futebol-brasil-2026.mjs --apply
npm start
```

Ao executar `--apply`, a migration v22 é aplicada se necessário e os dados são incluídos sem apagar os fatos existentes. O `--dry-run` é somente leitura. Execuções repetidas de `--apply` são idempotentes: cada fato tem identificador determinístico.

**Se utilizar o ZIP somente do Lote 019**, extraia os arquivos na pasta da aplicação depois de instalar a v0.30.13. O ZIP completo já contém o lote, portanto não é obrigatório baixar os dois.

#### Exemplos de perguntas

- Qual é o estádio do Sport?
- Quais os estádios dos clubes de Pernambuco?
- Quais os títulos do Sport?
- Qual a torcida estimada do Flamengo? (percentual AtlasIntel 2025)
- Qual o patrimônio líquido do Corinthians em 2025?
- Qual a receita do Palmeiras em 2025? (o dado disponível exclui vendas de jogadores)
- Qual série o Sport disputa em 2026?
- Quais clubes do Brasil participaram da Copa do Brasil em 2026?
- Quantas temporadas consecutivas o Flamengo disputa a Série A?

Os números de torcida representam **percentuais de respostas em pesquisa**, não milhões de pessoas. **Patrimônio líquido**, **receita** e **dívida** são métricas diferentes. Os históricos de participação **não estão completos** para toda a história dos clubes; foram incluídas apenas temporadas documentadas. Não inferir que um clube nunca disputou uma competição pela ausência de registros.

#### Modelo de dados

- `entity_facts`: `(entity, property, value, numeric_value, unit, reference_year, season, competition, source_url, source_note, origin_import)`.
- `entity_fact_aliases`: sinônimos controlados por propriedade, persistidos no SQLite.
- `entity_labels`: nomes legíveis dos clubes, sem modificar seus identificadores históricos.
- `knowledge_relations`: apenas novos fatos positivos de localização com proveniência em `relation_provenance`.

As fontes e as ressalvas **ficam gravadas em cada registro**, não apenas nesta documentação. O leitor `server/entity-facts.js` consulta as propriedades e equivalências armazenadas no banco. Nenhum dado novo treina automaticamente os pesos do modelo neural; trata-se de enriquecimento do conhecimento consultável.

#### Lacunas documentadas

O lote não contém a lista completa de temporadas da Série A desde sua criação, nem todas as edições da Copa do Brasil e dos 27 estaduais para cada clube. Patrimônio líquido e faturamento estão disponíveis apenas para os clubes com números individualmente confirmados nas fontes utilizadas. Tampouco há estimativa válida de torcida para todos os clubes. Esses campos ficaram **sem valor**, em vez de serem preenchidos com suposições.

#### Fontes principais

- [CBF — participantes da Série A 2025](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2025)
- [CBF — participantes da Série A 2026](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026)
- [CBF — participantes da Série B 2026](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026)
- [CBF — Copa do Brasil 2026](https://www.cbf.com.br/futebol-brasileiro/times/copa-do-brasil/masculino/2026)
- [Clubes e títulos por competição até outubro/2026](https://campeonato.net/clubes/)
- [Campeonatos estaduais e finalistas de 2026](https://campeonato.net/campeonatos-estaduais/)
- [AtlasIntel 2025 reportada pela CNN](https://www.cnnbrasil.com.br/esportes/futebol/flamengo-segue-na-lideranca-das-maiores-torcidas-do-brasil-veja-ranking/)
- [EY — finanças de clubes, balanços 2025](https://www.ey.com/pt_br/insights/media-entertainment/levantamento-financeiro-clubes-brasileiros)
- [ge — patrimônio líquido de clubes, 2025](https://ge.globo.com/pe/futebol/noticia/2026/06/03/dividas-dos-clubes-brasileiros-11-times-superam-r-1-bilhao-veja-ranking.ghtml)

---

### Lote 020 — Rankings brasileiros: torcida Datafolha 2026 e valuation Sports Value 2025

**Compatível com a MylittlIA Lab v0.30.14 ou superior.** Data de preparação: 07/11/2026. 

#### O que contém

- **47 fatos novos** em `entity_facts`, sem atualizar/alterar registros dos lotes anteriores.
- **30 valores estimados de valuation** (R$ milhões, Sports Value, levantamento de 2025).
- **17 percentuais de preferência por clube** (Datafolha, pesquisa de 22 e 23 de julho de 2026).
- Fonte, unidade, ano, identificador canônico e nota de metodologia **em cada fato**.
- Nenhuma estimativa convertida indevidamente em número absoluto de torcedores.

A fonte Datafolha publicou 18 linhas que incluem a Seleção Brasileira, que **não é um clube**; por isso o lote utiliza apenas os 17 clubes. A pesquisa ouviu 2.004 pessoas com 16 anos ou mais em 139 municípios, com margem de erro geral de 2 pontos percentuais. As posições de clubes empatados em percentual não significam diferença estatística comprovada.

**Valuation não é patrimônio líquido:** a Sports Value estima valor econômico de clubes/Safs; não equivale ao valor contábil dos ativos líquidos. O ranking seleciona o mesmo indicador, fonte, unidade e ano. A cobertura é limitada aos clubes publicados por cada estudo.

#### Como instalar sem apagar o conhecimento anterior

1. Encerre o Node.js e faça cópia de segurança da pasta `data/`.
2. Instale o ZIP **completo v0.30.14** sobre a instalação atual, mas **não substitua a pasta `data/`**.
3. Na raiz, execute:

```powershell
node imports/import-mylittlia-lote-020-rankings-brasil.mjs --dry-run
node imports/import-mylittlia-lote-020-rankings-brasil.mjs --apply
npm start
```

`--dry-run` é somente leitura. O primeiro `--apply` insere 47 fatos no banco ainda sem Lote 020; uma nova execução encontra os mesmos identificadores e adiciona zero fatos. Conflitos entre valores de mesma entidade, propriedade, fonte e ano provocam erro com **rollback** da transação. O importador não faz `UPDATE` ou `DELETE` e não altera os pesos da rede neural.

#### Teste na conversa

- **Quais os 3 maiores clubes do Brasil?** → pede critério, mostra exemplos, não lista todos.
- **Por torcida** (como continuação) → pesquisa Datafolha 2026: Flamengo (22%), Corinthians (14%), Palmeiras (7%).
- **Quais os 3 maiores clubes do Brasil por valuation?** → Sports Value 2025: Flamengo (R$ 5.096 mi), Palmeiras (R$ 4.395 mi), Corinthians (R$ 3.971 mi).
- **Quais os 5 maiores clubes de Pernambuco por valuation?** → informa somente os pernambucanos presentes no estudo, mais a limitação de cobertura.
- **Quais os 3 clubes com mais títulos da Copa do Brasil?** → utiliza a propriedade `quantidade_titulos` do Lote 019, filtrada pela competição, com ressalva de lacunas.
- **Quais os 10 animais mais rápidos?** → usa o mesmo mecanismo quando existirem fatos numéricos tipados e comparáveis de velocidade. A versão **não fabrica** velocidades ausentes.

O `server/comparative-ranking.js` é genérico: classe, propriedade, alias, unidades e valores vêm do SQLite. A migração **v23** acrescenta as tabelas `ranking_metrics`, `ranking_metric_aliases`, `ranking_metric_properties` e `ranking_metric_units`, com `INSERT OR IGNORE` e nenhum recadastramento de fatos históricos. A migração também acrescenta rótulos de UFs por `INSERT OR IGNORE` para melhorar a leitura das amostras.

#### Limitações e segurança dos dados

- O mecanismo não ordena por uma palavra vaga como **maior**: requer torcida, valuation, receita, patrimônio ou título de competição específica.
- Fontes, anos e unidades diferentes não são fundidos em uma classificação única.
- Indicadores não medidos, fontes sem ano e registros cuja unidade não corresponde ao catálogo são excluídos do ranking; o resultado informa cobertura parcial.
- `quantidade_titulos` do Lote 019 não forma automaticamente um total histórico consolidado de títulos de todas as competições.
- O registro de PIB estadual ou velocidade animal depende de fatos reais cadastrados: somente adicionar aliases/métricas não cria fatos.

#### Fontes originais

- [Datafolha (CNN Brasil, 01/08/2026)](https://www.cnnbrasil.com.br/esportes/futebol/datafolha-flamengo-segue-com-a-maior-torcida-do-brasil/) — entrevistas em 22–23/07/2026.
- [Sports Value — Valuation TOP 30 2025, 6ª edição](https://www.sportsvalue.com.br/case-studies/valuation-top-30-clubes-do-brasil-2025-6a-edicao/) — valores em milhões de reais.

#### Testes de engenharia

```powershell
npm run test:comparatives
npm run test:football019
npm run test:geography
npm run test:focus
npm run test:lexical
```

Os testes de comparação usam SQLite temporário, incluindo dados de clubes de outro país, anos diferentes, empates, critérios ambíguos, conversa sequencial e uma classe de animais de exemplo. **O teste completo (`npm test`) permanece limitado pelo arquivo legado `data/seed.json` ausente nos pacotes recebidos.**

## Segurança dos dados e atualização

**Não sobrescreva a pasta `data/` nem modelos/checkpoints pessoais.** Pare o Node.js e feche editores de SQLite antes de atualizar. Faça backup do arquivo de banco e da pasta `data/`, além de `models/generated/` se existir na sua instalação. O ZIP de atualização não inclui banco pessoal, arquivos WAL/SHM nem checkpoints treinados.

As migrations da aplicação são controladas por versão do schema. Faça backup antes da primeira inicialização após uma atualização que acrescente migrations.

## Documentação de versões

O projeto mantém **somente este `README.md`** como documentação principal, atualizado incrementalmente. Consulte [`CHANGELOG.md`](CHANGELOG.md) para o histórico de atualizações e correções. Não criar READMEs adicionais por versão, lote ou funcionalidade.


## v0.21 — Contexto semântico conversacional

O chat preserva o assunto das mensagens anteriores no histórico do SQLite, solicita esclarecimento para “maiores cidades” sem critério e interpreta respostas curtas como “em extensão” ou “por população”. Os filtros “e em 2025?”, “somente as capitais” e “do Nordeste” são reconhecidos, mas quando não existe consulta fundamentada para aplicá-los o sistema declara a limitação. O inspetor mostra a consulta antes e depois do complemento. Não há migração nova; nada é gravado em JSON.


## Consultas numéricas e rankings dinâmicos (v0.22)
A MylittlIA pode calcular uma classificação **parcial** com medidas municipais presentes em `knowledge_relations`. Para cada município, cadastre um vínculo `pertence_a` apontando para o estado (por exemplo `recife → pertence_a → pernambuco`) e uma medida com o ano de referência, como `recife → area_km2 → 218,84 km2 em 2025` ou `recife → populacao → 1.500.000 habitantes em 2025`. Também aceita `pib` em reais. Os números neste exemplo são **ilustrativos**, não estatísticas oficiais; obtenha medidas verificadas antes de importar.

A consulta permite `maiores cidades de PE em extensão`, `por população` ou `por PIB`, e acompanha o complemento contextual `em extensão`. O resultado é ordenado pelos valores armazenados e traz aviso de cobertura parcial. Se faltam dados ou os anos divergem, o sistema informa a limitação e não fabrica um ranking. A aba técnica do inspetor pode consultar `interpretation.ranking`, `interpretation.year`, `interpretation.metric` e o caminho das relações utilizadas.

**Esta versão não importa dados municipais novos, não altera migrations e não mexe em pesos neurais.**


## Ensino por listas na conversa (v0.22.1)
Uma lista fornecida depois de um convite para ensinar, inclusive precedida de “Sim, posso”, fica pendente de aprovação em **Cadastrar conhecimento**. A lista não vira automaticamente um conjunto de medidas numéricas nem treina os pesos da rede. A integração de cada linha com rankings numéricos requer extração estruturada posterior.


## v0.23 — Ensino de listas numéricas
Envie na conversa uma lista numerada com municípios e km² depois do convite para ensinar. O conteúdo será pendente até aprovação na área de conhecimentos. Ao aprovar, serão inseridas relações `pertence_a` e `area_km2`, sem alterar relações anteriores. O ranking calculado só considera municípios com medidas comparáveis; quando não há ano, não apresenta o ranking como oficial. Para corrigir valores diferentes já existentes, revise manualmente: a importação não substitui medidas conflitantes. Listas de medidas não devem ser utilizadas diretamente no laboratório gerativo por palavras.

## Revisar os ensinamentos recebidos
Na tela de treinamento, clique em **Cadastrar conhecimento** para revisar os ensinamentos pendentes. Marque os itens, aprove ou rejeite. O botão **Salvar pergunta e resposta** é destinado ao cadastro manual.


### Rankings sem ano (v0.23.2)
O mecanismo distingue ano ausente de anos conflitantes. Se todas as medidas não tiverem ano, apresenta somente classificação indicativa; quando há um ano explícito único, usa apenas registros datados daquele ano. Não altera o banco.


### v0.23.3 — rankings com períodos mistos
Quando existem medidas de diferentes anos ou sem ano, o motor escolhe o grupo com mais municípios (em empate, ano mais recente) e informa o período e os itens excluídos. Não mistura datas nem modifica dados de origem.


### Consulta singular (v0.23.4)
Perguntas como “Qual a maior cidade de Pernambuco em extensão territorial?” usam o ranking numérico de municípios com medidas cadastradas e deixam clara eventual cobertura parcial.


### Operações sobre conjuntos (v0.23.5)
O chat aceita ordinais, limites, filtros por medidas e pedidos de inclusão de todos os registros disponíveis. Dados com anos diferentes não são apresentados como ranking oficial ou temporalmente comparável. Os resultados refletem apenas municípios cadastrados. A frase “não deixe nenhuma de fora” atualiza a consulta anterior em vez de iniciar uma nova pergunta.


## v0.24 — Separação entre inferência e apresentação

O motor de inferência continua responsável por calcular, selecionar períodos e informar registros excluídos. `server/language-engine.js` recebe o resultado estruturado e produz uma resposta mais natural em português brasileiro. O texto técnico original fica em `inferenceAnswer` no resultado, sem ser confundido com a resposta exibida.


A versão exibida na aplicação vem do `package.json` por `/api/version`. Os favicons são `favicon.png` e `favicon.ico`.


### Interface v0.24.3
O botão Exportar trace JSON fica no rodapé à direita do Fluxo entre camadas e só fica habilitado após uma execução.

### Atalho de mensagem
No campo **Mensagem**, pressione **Enter** para enviar ou **Shift+Enter** para inserir uma nova linha. O botão **Enviar** continua disponível.


### Avaliação automática de relações (v0.25)
Na tela de treinamento, expanda **Relações e pesos de inferência** e use **Simular avaliação** antes de **Avaliar em lote**. A avaliação armazena sinais de evidência e conflitos em `relation_assessments`, sem modificar `knowledge_relations.confidence`. A origem declarada de uma relação não constitui verificação independente.

## v0.26 — Conversa básica e avaliações de relações

- A MylittlIA responde a saudações, identidade, versão, hora e data (fuso padrão America/Recife; configure `MYLITTLIA_TIMEZONE`).
- A pergunta sobre o que está aprendendo consulta as quantidades reais no SQLite. Não representa treinamento automático em segundo plano.
- Caminhos de inferência usam o peso manual quando presente. Sem peso manual, aceitam a pontuação da tabela `relation_assessments` somente com `status=evidence`. Relações com revisão ou conflito permanecem sem peso automático.
- **Atenção:** avaliação automática é uma heurística de qualidade da evidência, não confirmação de verdade. Para povoar a tabela, execute a avaliação em lote na tela de ensino.

### Localização no grafo (v0.26.1)
Perguntas como “O Amapá fica no norte do Brasil?” consultam a relação `localizado_em` já cadastrada. Peso não avaliado não impede recuperar um fato, mas não implica verificação independente.


Na v0.26.2, uma resposta ao convite de ensino só vira pendência quando contém uma explicação ou dados reconhecíveis; saudações e mudanças de assunto são tratadas normalmente.

### Consultas temporais (v0.26.3)
A conversa reconhece perguntas de calendário como "E amanhã?", "Que dia foi ontem?", "Daqui a 10 dias", "Qual dia da semana será 15 de novembro de 2026?", "Quantos dias faltam para o Natal?" e "Próximo domingo". A data considera o fuso `MYLITTLIA_TIMEZONE` (padrão `America/Recife`) e não depende de fatos cadastrados.

### Núcleo neural experimental v0.27
O backend possui um **classificador de intenções desenvolvido e treinado do zero**, sem usar Ollama ou modelos pré-treinados. A rede tem entrada de 384 dimensões baseada em n-gramas de caracteres, camada oculta ReLU de 28 neurônios e seis saídas softmax. O treinamento utiliza exemplos internos e gradiente descendente, e o primeiro uso salva os pesos em `neural_intent_models` no SQLite (migration v8). Não substitui o gerador experimental anterior.

O classificador é auxiliar: quando sua avaliação é suficientemente forte, ajuda a roteirizar saudações e perguntas e evita confundir algumas perguntas com ensino. O reconhecimento de fatos continua usando o grafo SQLite, e os cálculos continuam determinísticos. O registro `neuralIntent` da resposta da API inclui a intenção prevista e candidatos para análise. As pontuações **não são medidas de verdade factual nem probabilidades calibradas**.

Limitações: treinamento inicial com poucos exemplos, sem atualização automática do modelo após cada conversa, sem Transformer e sem geração linguística livre. O motor pode errar perguntas inéditas; pedidos de ensino continuam sujeitos a aprovação.

### Identidade visual
O ícone de cérebro com circuitos é usado no favicon (`favicon.png` / `favicon.ico`) e no cabeçalho da aplicação.

## Tempos de execução (v0.27.2)
O fluxo não avança por um temporizador artificial. São exibidos tempos reais de operações locais medidas com `performance.now()`. As etapas executadas juntas no servidor mostram “Tempo não isolado”; a duração de cada chamada HTTP e a duração total observada são armazenadas no trace. A instrumentação granular do servidor poderá ser adicionada posteriormente; não se apresentam números estimados como reais.

### Feedback sobre raciocínio e rankings do Brasil (v0.28.4)
Quando o usuário questiona uma resposta sobre ranking populacional e sugere reaproveitar os dados já existentes, a MylittlIA distingue **orientação sobre o processo** de **afirmação factual**. A conferência utiliza relações de município/UF e valores numéricos de população efetivamente armazenados no SQLite. Listas de referência sem habitantes individuais não são suficientes para determinar um líder nacional. Na presença de medidas, pode gerar um ranking **parcial e com período identificado**; não representa cobertura integral do país. Esse diálogo não aciona a avaliação de 0 a 100, nem grava um ensinamento. Não há migration nesta versão.


### v0.29.8 — Identidade e capacidades
Perguntas como “e o que você faz?” utilizam as capacidades reais do aplicativo. Data de criação e autoria não são inferidas do relógio ou de informações pendentes de aprovação.


### v0.29.9 — Perguntas de acompanhamento
Após perguntar pelas maiores cidades, é possível responder "população" e depois "e extensão vc sabe?". Os rankings requerem registros numéricos e vínculos territoriais válidos no SQLite.


### Correção v0.29.11
Perguntas sobre nova entidade não herdam indevidamente as relações do assunto anterior. Teste: `node tests/context-topic-v02911.test.mjs`.

### v0.29.12
Consultas diretas com “então” e perguntas de classificação de animais agora consultam relações explícitas do SQLite. A ausência de uma relação não comprova negação.

### v0.29.14 — Linguagem da conversa
As consultas amplas sobre animais usam linguagem natural na conversa. A contagem e a origem SQLite permanecem nos metadados de interpretação, sem aparecer desnecessariamente na resposta.


### v0.30.0 — Respostas configuráveis
Os templates ficam em `conversational_templates` (SQLite), criados pela migration v12 uma única vez. É possível alterar `template_text` no SQLiteStudio; as próximas inicializações preservam a alteração. Variáveis permitidas são preenchidas pelo motor. Esta etapa migra os textos de `self-awareness.js` e `topic-summary.js`; outros módulos ainda serão migrados gradualmente.


### v0.30.2 — Classificações em contexto
Ao conversar sobre grupos de animais, perguntas como “Onde se encaixa o cachorro nesses grupos?” consultam diretamente a classificação `e_um` no SQLite e produzem resposta via template editável `context-animal-classes`. Ausência de registros não é transformada em uma certeza negativa. A migration v14 é automática e não altera conhecimentos nem pesos.


### Histórico de mensagens (v0.30.3)
No campo Mensagem, pressione ↑ para recuperar as mensagens enviadas anteriormente nesta conversa e ↓ para voltar às mais recentes. Ao retornar ao início da navegação, o rascunho digitado é restaurado. Shift+↑/↓ mantém a navegação convencional no texto.


### v0.30.5 — Som e continuidade da conversa

A consulta sobre vocalizações usa `knowledge_relations` (`som_emitido`, `emite_som`, `vocalizacao`, `vocaliza`, `onomatopeia`, `faz_som`) e frases em `semantic_predicate_phrases` criadas pela migration v16. A pergunta “Ele faz algum som?” pode recuperar o último animal mencionado **na mesma conversa**. Entidades explicitamente mencionadas têm prioridade sobre o contexto anterior. Ausência de fato não é interpretada como uma negativa.

Ensinamentos enviados em resposta a um convite são registrados em `conversational_teachings` e **não são incorporados automaticamente**. É necessária aprovação pelo fluxo de revisão da aplicação. O Lote 015 contém fatos introdutórios opcionais sobre vocalizações; para importar, simule e depois aplique com os dois comandos de sempre.


### v0.30.6 — Consulta contextual ampliada
O motor pode recuperar propriedades diferentes da mesma entidade em uma sequência conversacional. Perguntas com pronomes como "Onde ele vive?" e "O que ele come?" utilizam o último sujeito pertinente do histórico; entidades explícitas continuam prevalecendo. Consultas ao próprio conceito "latido" dependem da relação `latido -> onomatopeia -> au_au`, disponibilizada pelo Lote 016. Os modelos de texto ficam no SQLite, via migration v17. A ausência de relações permanece uma lacuna, não uma resposta falsa.

**Teste focado:** `npm run test:context-general`.

**Lote 016:** extrair o ZIP na raiz do projeto, executar `node imports/import-mylittlia-lote-016-sons-e-linguagem.mjs --dry-run`, conferir e, após backup, executar `node imports/import-mylittlia-lote-016-sons-e-linguagem.mjs --apply`.

## Novidade v0.30.7 — ensino de várias relações numa conversa

Digite, por exemplo: `O Sport é um clube de futebol de Pernambuco. Suas cores são vermelho e preto.`
A MylittlIA apresenta as quatro relações extraídas e as coloca em **Cadastrar conhecimento** para revisão individual. **Nada é incorporado automaticamente.** Antes de aprovar, use **Editar relação** para corrigir sujeito, predicado, objeto, fonte e ano. Depois da aprovação, faça perguntas como:

- `Quais cores o Sport possui?`
- `Cite um clube de futebol de Pernambuco.`
- `Onde fica o Sport?`
- `Quais clubes você conhece que usam vermelho?`
- `O que você sabe sobre o futebol de Pernambuco?`

Novos arquivos: `server/conversational-graph.js`, `server/migration-v18.sql`, `tests/conversational-learning-v0307.test.mjs`. Dados pessoais e pesos são preservados. A migration adiciona metadados em `knowledge_proposals` e `relation_provenance`.

Para testar: `npm run test:learning`.

### Lote 017 opcional

O pacote separado `MylittlIA-Lote-017-Futebol-Geografia.zip` contém somente `imports/import-mylittlia-lote-017-futebol-pernambuco.mjs`. Depois de instalar e iniciar a aplicação v0.30.7, execute:

```powershell
node imports/import-mylittlia-lote-017-futebol-pernambuco.mjs --dry-run
node imports/import-mylittlia-lote-017-futebol-pernambuco.mjs --apply
```

Faça backup do SQLite antes de `--apply`. O importador lê o banco existente, não cria outro, valida os dados dentro de uma transação (rollback no dry-run), evita duplicações e não atualiza pesos antigos. São 18 relações com fontes institucionais dos clubes e IBGE, incluindo o bioma predominante de Recife (referência 2024).

### Limites e cuidados

- O extrator reconhece estruturas declarativas comuns (classe, localização, cores, alimentação), mas não equivale a compreensão linguística ilimitada. Frases não reconhecidas permanecem no fluxo legado.
- Na revisão, a fonte e o ano podem ser adicionados manualmente, porém a aplicação ainda não faz checagem independente desses documentos.
- Correções de fatos conflitantes exigem revisão: propriedades singulares não são substituídas silenciosamente. A edição integrada é de propostas **antes da aprovação**.
- A consulta inversa não inventa ranking de importância nem títulos/torcidas sem dados e critérios documentados.
- A suíte legada completa inclui testes que exigem `data/seed.json`, ausente do pacote de origem; os testes novos e direcionados foram executados.


## v0.30.8 — Nomes compostos e aprendizado entre estados

A extração de ensinamentos reconhece localizações com nomes compostos consultando estados e categorias já armazenados no SQLite (`tem_capital` e `e_um`). Corrige casos como Rio de Janeiro e Rio Grande do Norte, preserva revisão/aprovação no painel e não grava conhecimento sem aprovação. O importador corrigido do Lote 017 aplica a migration v18 durante `--apply`, sem exigir comando extra. O Lote 018 traz 303 relações nacionais de clubes da Série D 2026, UFs/capitais/regiões e biomas documentados.

### Lotes 017 corrigido e 018 nacional

Os dois importadores ficam em `imports/` e mantêm o padrão `--dry-run` e `--apply`. O `--dry-run` não altera o banco, mesmo que a migration v18 esteja pendente. O `--apply` executa migrations pendentes com `openDatabase(...,{seed:false})` antes de inserir os fatos e sua procedência. **Faça backup de `data/` e encerre o Node.js antes de aplicar.** A importação é idempotente e nunca sobrescreve pesos ou relações existentes.

- `node imports/import-mylittlia-lote-017-futebol-pernambuco.mjs --dry-run` e depois `--apply` — 18 relações de Pernambuco.
- `node imports/import-mylittlia-lote-018-brasil-futebol-biomas.mjs --dry-run` e depois `--apply` — 383 relações nacionais: 136 clubes dos campeonatos A, B e D de 2026, 27 unidades federativas/capitais/regiões, seis biomas e 24 associações de bioma predominante apoiadas em documentação IBGE.

**Escopo:** a fonte CBF confirma participantes por federação nas competições de 2026. O lote **não** estabelece ranking de importância, cores, títulos, torcidas ou população negra. Os dados geográficos de bioma são macroterritoriais, não equivalem a uma vegetação uniforme. Essas consultas só podem ser respondidas quando houver dados específicos com fonte e referência.


### v0.30.12: consultas nacionais por inferência
A pergunta “Quais os clubes do Brasil?” agora percorre clube → cidade/estado → Brasil a partir de relações já aprovadas. Uma UF marcada `unidade_federativa_brasileira` ou `estado_brasileiro` pertence ao Brasil para fins de consulta; isso não cria novos conhecimentos persistidos. As listas refletem somente os dados conhecidos, não todos os clubes existentes. Não se inferem automaticamente cores, títulos, receitas ou tamanhos de torcida.


### Correção do aprendizado de quantidade de patas
Ensinamentos como “O pato possui 2 patas” são apresentados para revisão em Cadastrar conhecimento. Após aprovação, consultas de quantidade usam a relação numero_patas_tipico. Reconhece números e palavras de zero a dez, artigos e introdução corretiva “Não,”. “Sempre” é normalizado como quantidade típica, sem comprovar universalidade. Valores conflitantes exigem corrigir ou rejeitar a proposta; não substituem o valor aprovado. Não migra registros antigos extraídos incorretamente. Teste: node tests/limb-learning.test.mjs.

Correção adicional: consultas de quantidade de patas usam somente numero_patas_tipico, sem aceitar penas ou outras características como resposta. Na ausência desse dado aprovado, informam a lacuna. Reconhece a retomada explícita “mas eu perguntei sobre as patas do pato”. Registros antigos não são alterados.


### v0.30.15 — Recuperação de ensinamentos do histórico
Ao perguntar a quantidade de patas de uma entidade sem esse dado no grafo, a aplicação procura ensinamentos explícitos do usuário no histórico disponível da mesma conversa. Recupera como proposta pendente, apresenta o valor e permite revisar em Cadastrar conhecimento. Não aprova automaticamente, não utiliza respostas da IA, não reabre propostas rejeitadas nem altera relações antigas. Após aprovação, responde pela relação estruturada. Usa até as 500 mensagens disponibilizadas pelo histórico atual. Não é treinamento neural nem recuperação universal de fatos.
Teste direcionado: npm run test:learning-recovery. Reproduzido também em uma cópia do banco enviado, com aprovação e reabertura. A suíte geral foi interrompida por EBUSY no encerramento de tests/sqlite.test.mjs no Windows. O pacote de atualização não contém bancos, históricos nem modelos pessoais. Preserve a pasta data e reinicie o servidor após atualizar.


### v0.30.16 — Extração e aprovação por entidade
Explicações reconhecidas sobre vocalizações são separadas em relações: cachorro → som_emitido → latido; latido → onomatopeia → au_au; gato → som_emitido → miado; miado → onomatopeia → miau. Formas verbais reconhecidas: late, mia, muge, grasna, relincha e uiva. Isso é interpretação por regras, não compreensão universal nem treinamento neural.

Em Cadastrar conhecimento, pendências antigas apresentam os fatos extraídos antes de Aprovar selecionados. A aprovação grava as relações mostradas em uma transação e preserva a explicação original; não cria uma resposta geral para a pergunta com pronome. Relações idênticas não são duplicadas nem têm seus pesos substituídos. Sem fatos com entidade identificada, perguntas dependentes de pronome são bloqueadas para aprovação, mesmo com confirmação manual. Reformule com o nome da entidade. Respostas antigas cadastradas sob perguntas com pronomes são excluídas da recuperação geral, sem apagar registros.

As consultas de som recuperam também a onomatopeia ligada ao nome do som. Teste: npm run test:entity-teaching. Validado com a pendência real em uma cópia do banco, preservando os registros anteriores e reabrindo o banco. A revisão visual no navegador não foi automatizada.


### v0.30.17 — Apresentação natural dos sons
A resposta padrão separa a vocalização da representação escrita: “Cachorro late. Esse som pode ser representado por ‘au au’.” A migration v24 atualiza somente o texto padrão antigo, preserva personalizações e não altera conhecimentos. Ao reiniciar o servidor, a atualização é aplicada ao banco existente. Não é necessário reaprender nem aprovar os fatos novamente. Teste: npm run test:sound-wording.


### v0.30.18 — Lote 021: clubes de referência nas 27 UFs

A seleção solicitada pelo usuário contém 117 clubes. O pacote inclui 528 registros com procedência: contagens estaduais, conquistas e vices em competições nomeadas, torcida, receitas, patrimônio líquido, valuation e endividamento. Na cópia do banco da instalação, 28 registros já existiam e 500 foram acrescentados sem alterar os anteriores.

**Cobertura incompleta:** há contagens estaduais numéricas para 116 clubes (Rio Branco-AC permanece com divergência de 48/49), torcida para 22, receita para 30, patrimônio líquido para 30, valuation para 28 e endividamento para 22. Isso não satisfaz a cobertura dos quatro indicadores para quatro clubes em todas as UFs. As lacunas são explicitadas e não recebem valor zero. São 261 registros adicionais de títulos e vices, separados por competição e com corte até 2025. As contagens estaduais seguem fontes consultadas em 2026. Brasil de Pelotas inclui a ressalva do título honorífico de 1918. O CRB tem 45 conforme reconhecimento divulgado em agosto de 2026.

Fontes: tabelas de campeonatos da Wikipédia; relatórios individuais PLURI (edição 2025, exercício 2024); Sports Value (finanças 2025 e valuation 2025); demonstrações dos clubes e federações; Datafolha de Pernambuco, divulgado por Cassio Zirpoli. Cada valor conserva URL, exercício, unidade, série e ressalvas. Valuation não substitui patrimônio líquido. Pesquisas estaduais e nacionais não são misturadas. Estimativas PLURI são identificadas como estimativas divulgadas no relatório, sem assumir coleta de campo em 2025.

**Instalação:** encerre o servidor, faça backup da pasta data, extraia a atualização e reinicie. A migration v25 amplia a procedência e o servidor importa o Lote 021 automaticamente ao iniciar. Uma marca de conteúdo evita reimportações. A operação é aditiva e transacional; conflitos de valor com mesma fonte/ano interrompem o lote sem substituir dados. Identificadores de clubes são separados dos de municípios, incluindo Floresta-CE, Rio Branco-AC, Palmas e Macapá. Nenhum banco pessoal acompanha o pacote.

Simulação opcional, sem migração ou escrita: `npm run import:football021 -- --dry-run`. Aplicação manual: `npm run import:football021 -- --apply`. Testes: `npm run test:football021`, `npm run test:comparatives`, `npm run test:geography`.

Sem critério explícito, os exemplos de Pernambuco passam a ser Sport, Náutico e Santa Cruz; a lista nacional agrupa referências por UF. Essa ordem editorial não é apresentada como ranking estatístico. Com critério, o motor usa os valores comparáveis de uma série, com fonte e período, e sinaliza cobertura parcial. Material auxiliar recebido sem fontes ou períodos é mantido como pendência de pesquisa, sem transformar faixas em valores confirmados.


### v0.30.19 — Métrica com domínio implícito
Consultas como “qual a maior torcida em Pernambuco?” passam a identificar a comparação de clubes pelo significado da métrica no catálogo SQLite (migration v26). Não é necessário mencionar “time” ou “clube”. Expressões de localização como “no estado de Pernambuco” não substituem a classe comparada. Perguntas singulares exibem um resultado; plurais e limites explícitos são preservados. Após uma pergunta de critério, “por torcida” e “torcida” mantêm o lugar da pergunta anterior. O Lote 021 não precisa ser importado novamente; a atualização não altera seus fatos. Teste: npm run test:implicit-ranking. Validado com a pergunta exata e variações em uma cópia do banco da instalação.
